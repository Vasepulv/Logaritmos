package test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import base.Algorithm;

class AlgorithmBasicTest {
	
	
	@Test
	void test1() {
		// Ejemplo del enunciado
		ArrayList<ArrayList<Integer>> result = Algorithm.solucionar("ananas", "banana");
		assertTrue(Arrays.equals(new Object[] {6,5,4,3,2,1,2}, result.get(0).toArray()));
		assertTrue(Arrays.equals(new Object[] {6,6,5,4,3,3,2}, result.get(1).toArray()));
	}

	@Test
	void test2() {
		// https://www.cs.jhu.edu/~langmea/resources/lecture_notes/dp_and_edit_dist.pdf
		// Ahí la tabla de ejemplo
		ArrayList<ArrayList<Integer>> result = Algorithm.solucionar("GCTATGCCACGC", "GCGTATGCACGC");
		assertTrue(Arrays.equals(new Object[] {12,11,10,9,8,7,6,5,4,4,3,3,2}, result.get(0).toArray()));
		assertTrue(Arrays.equals(new Object[] {12,11,10,9,9,8,8,7,6,5,4,3,2}, result.get(1).toArray()));
	}
	

}

