package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import base.StringGen;

class StringGenTest {
	StringGen s1;
	StringGen s2;
	
	@BeforeEach
	void setUp() {
		s1 = new StringGen();
	}
	
	@Test
	void test() {
		// Esto verifica que los dos metodos para pedir caracteres hacen lo mismo.
		String charByChar;
		String fullSlice;
		int largo = 50; 
		StringBuilder builder = new StringBuilder();
		for(int i = 0; i < largo; i++) {
			builder.append(s1.getCharAt(i));
		}
		charByChar = builder.toString();
		fullSlice = s1.getSubString(0, largo);
		assertTrue(charByChar.equals(fullSlice));
	}

}
