import java.io.*;

import java.util.Iterator;

public class IOExample {
    public static void main(String[] args) {

        // Vamos a guardar un objeto Rectangle en un archivo
        // La  clase Rectangle debe implementar la interfaz Serializable
        Rectangle object = new Rectangle(0, 0, 1, 1);

        String dir = "C:\\Users\\Javier\\Desktop"; // Carpeta en donde esta el archivo
        String fileName = "rec.bin"; // Nombre del archivo

        // Se guarda el archivo
        try {
            FileOutputStream fos = new FileOutputStream(dir + "\\" + fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(object);
            oos.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Rectangle object2;
        // Ahora tratamos de leerlo
        try {
            FileInputStream fis = new FileInputStream(dir + "\\" + fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            object2 = (Rectangle) ois.readObject();
            ois.close();
            fis.close();
            System.out.println(object2.toString()); // Despues de leerlo imprimimos sus valores
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Tambien vemos cuanto pesa el archivo
        File f;
        try {
            f = new File(dir + "\\" + fileName);
            if(f.exists()) {
                System.out.println("file length: "+ f.length() + " bytes"); // File.length() retorna bytes
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}